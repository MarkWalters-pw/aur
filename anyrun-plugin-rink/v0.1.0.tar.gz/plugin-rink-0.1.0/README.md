# Rink

A simple calculator plugin powered by [Rink](https://github.com/tiffany352/rink-rs).

## Usage

Just type in your calculations/unit conversions.
