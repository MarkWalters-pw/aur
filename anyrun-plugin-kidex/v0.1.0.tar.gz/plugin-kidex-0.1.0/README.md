# Kidex

A plugin to search files using the [Kidex](https://github.com/Kirottu/kidex) file indexing daemon.

## Usage

As long as the Kidex daemon is running, simply look up the file names.

## Configuration

```ron
// <Anyrun config directory>/kidex.ron
Config(
  max_entries: 3,
)
```
