# Available PyMusicLooper CLI Commands

## pymusiclooper

![`pymusiclooper --help`](img/pymusiclooper.svg)

## pymusiclooper play

![`pymusiclooper play --help`](img/pymusiclooper-play.svg)

## pymusiclooper play-tagged

![`pymusiclooper play-tagged --help`](img/pymusiclooper-play-tagged.svg)

## pymusiclooper export-points

![`pymusiclooper export-points --help`](img/pymusiclooper-export-points.svg)

## pymusiclooper split-audio

![`pymusiclooper split-audio --help`](img/pymusiclooper-split-audio.svg)

## pymusiclooper tag

![`pymusiclooper tag --help`](img/pymusiclooper-tag.svg)

## pymusiclooper extend

![`pymusiclooper extend --help`](img/pymusiclooper-extend.svg)
